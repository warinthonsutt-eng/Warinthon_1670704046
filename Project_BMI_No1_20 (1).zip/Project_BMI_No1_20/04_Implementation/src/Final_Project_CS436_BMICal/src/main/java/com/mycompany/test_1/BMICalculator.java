/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.test_1;

/**
 *
 * @author zooca
 */
public class BMICalculator {
    
    public static double calculateBMI(double weight, double height) {
        double heightM = height / 100.0;
        return weight / (heightM * heightM);   
}
    public static String getAdvice(double bmi) {
        String advice;

        if (bmi < 18.5) {
            advice = """
                     Underweigh
                     You are within a healthy weight range. Keep up the good habits!
                     Maintain a balanced diet with plenty of fruits, vegetables, and whole grains.
                     Engage in regular physical activity such as walking, jogging, or swimming.
                     Monitor your weight periodically to ensure it stays within the healthy range.""";
        } else if (bmi < 23) {
            advice = """
                     Normal weight
                     You are within a healthy weight range. Keep up the good habits!
                     Maintain a balanced diet with plenty of fruits, vegetables, and whole grains.
                     Engage in regular physical activity such as walking, jogging, or swimming.
                     Monitor your weight periodically to ensure it stays within the healthy range.""";
        } else if (bmi < 25) {
            advice = """
                     Slightly overweight
                     You are slightly overweight. Consider making adjustments to your lifestyle.
                     Reduce the intake of sugary, fatty, and salty foods.
                     Increase your physical activity to burn extra calories, such as brisk walking or cycling.
                     Focus on small, consistent changes in diet and exercise for sustainable results.""";
        } else if (bmi < 30) {
            advice = """
                     You are classified as obese (level 1). This can increase the risk of health issues.
                     Start a structured diet plan with controlled portions and healthier food choices.
                     Incorporate regular exercise, including both cardio and strength training.
                     Consider consulting a healthcare professional for personalized guidance and monitoring.""";
        } else {
            advice = """
                     Obese level 2
                     You are classified as obese (level 2). There is a higher risk of serious health problems.
                     It is important to seek guidance from healthcare professionals or dietitians.
                     Adopt a carefully monitored diet and exercise plan to reduce weight safely.
                     Regular check-ups and support are essential to manage your health effectively.""";
        }

        return advice;
    }
}