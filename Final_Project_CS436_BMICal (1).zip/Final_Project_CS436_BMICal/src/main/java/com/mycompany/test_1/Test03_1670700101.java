/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.test_1;

/**
 *
 * @author zooca
 */
public class Test03_1670700101 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
